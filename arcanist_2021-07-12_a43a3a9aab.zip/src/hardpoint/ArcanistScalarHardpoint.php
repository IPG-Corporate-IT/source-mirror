<?php

final class ArcanistScalarHardpoint
  extends ArcanistHardpoint {

  public function isVectorHardpoint() {
    return false;
  }

}
