<?php

abstract class ArcanistConduitException extends Exception {}
