<?php

final class PhutilRegexException extends Exception {}
