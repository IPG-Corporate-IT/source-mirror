<?php

abstract class ArcanistWorkingCopyConfigurationSource
  extends ArcanistFilesystemConfigurationSource {}
