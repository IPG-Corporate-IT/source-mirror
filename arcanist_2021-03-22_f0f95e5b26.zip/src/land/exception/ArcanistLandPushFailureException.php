<?php

final class ArcanistLandPushFailureException
  extends Exception {}
