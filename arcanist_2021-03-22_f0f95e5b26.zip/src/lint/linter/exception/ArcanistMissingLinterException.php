<?php

final class ArcanistMissingLinterException extends Exception {}
